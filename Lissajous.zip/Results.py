# Importing libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
#from scipy import stats
#from scipy.optimize import curve_fit

#%% First part
CH1 = {}
CH2 = {}
for i in range (1,9):
    # Obtains CH1 and CH2 data from .csv files and places them in dictionaries
    if i == 1:
        dataset = pd.read_csv('f'+str(i)+'new.csv')
    else:
        dataset = pd.read_csv('f'+str(i)+'.csv')
    CH1[i] = dataset.iloc[1:, 1].values.astype(float)
    CH2[i] = dataset.iloc[1:, 2].values.astype(float)
    
    # Visualizing
#    plt.figure(figsize=(5,5))
#    plt.scatter(CH1[i],CH2[i])
#    plt.xlabel('CH1 Voltage (V)')
#    plt.ylabel('CH2 Voltage (V)')
#    plt.grid(axis='y')
#    plt.savefig('Figure'+str(i)+'.png')
    
#%% Second part
X = {}
Y = {}
Vx = {}
Vy = {}
V1 = {}
V2 = {}
for i in range(200,1001,200):
    # Obtains data
    dataset = pd.read_csv(str(i)+'.csv')
    X[i] = dataset.iloc[1:, 1].values.astype(float)
    Y[i] = dataset.iloc[1:, 2].values.astype(float)
    
    # Visualizing
#    plt.figure(figsize=(5,5))
#    plt.scatter(X[i],Y[i])
#    plt.xlabel('Source Voltage (V)')
#    plt.ylabel(r'$V_R$ (V)')
#    plt.grid(axis='y')
#    plt.savefig(str(i)+'-Hz.png')
    
    # Determines ellipse "properties"
    V1[i] = max(abs(X[i]))
    V2[i] = max(abs(Y[i]))
    Vx[i] = abs(X[i][np.argmin(abs(Y[i]))])
    Vy[i] = abs(Y[i][np.argmin(abs(X[i]))])
    
X2 = {}
Y2 = {}
Vc = {}
Vr = {}
V_add = {} # V_add = sqrt(Vc^2 + Vr^2)
for i in range(200,1001,400):
    dataset = pd.read_csv('2_'+str(i)+'.csv')
    X2[i] = dataset.iloc[1:, 1].values.astype(float)
    Y2[i] = dataset.iloc[1:, 2].values.astype(float)
    
    Vc[i] = max(Y2[i])
    Vr[i] = max(Y[i])
    V_add[i] = np.sqrt(Vc[i]**2 + Vr[i]**2)
    
print('\nFreq. (Hz)\tVx\tVy\tV1\tV2')
for j in range(200,1001,200):
    print(str(j)+'\t\t'+str(Vx[j])+'\t'+str(Vy[j])+'\t'+str(V1[j])+'\t'+str(V2[j]))
    
print('\nFreq. (Hz)\tVc\tVr\tV_add')
for j in range(200,1001,400):
    print((str(j)+'\t\t'+str(Vc[j])+'\t'+str(Vr[j])+'\t%.4f') % V_add[j])